#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    // Checks for right number of command line arguments - DONE
    if (argc == 1 || argc > 2)
    {
        printf("Error\n");
        return 1;
    }

    // Converts argument into an integer - DONE
    string string_key = argv[1];

    int key = atoi(string_key);
    double dkey = key;

    if (dkey / 2 == 0)
    {
        printf("Error\n");
        return 1;
    }

    // Input text - DONE
    string text = get_string("plaintext: ");
    int textlen = strlen(text);

    printf("ciphertext: ");
    // For loop to go through the string - DONE
    for (int i = 0; i < textlen; i++)
    {
        // Checks if character is uppercase and adds the key - DONE
        if ( islower(text[i]) == false && isdigit(text[i]) == false && isspace(text[i]) == false && ispunct(text[i]) == false )
        {
            int charactervalue = text[i];
            int alphaindex = charactervalue - 65;

            int character_ciphervalue = ( (alphaindex + key) % 26 ) + 65;
            printf("%c", character_ciphervalue);
        }

        // Checks if character is lowercase and adds the key - DONE
        else if ( isupper(text[i]) == false && isdigit(text[i]) == false && isspace(text[i]) == false && ispunct(text[i]) == false )
        {
            int charactervalue = text[i];
            int alphaindex = charactervalue - 97;

            int character_ciphervalue = ( (alphaindex + key) % 26 ) + 97;
            printf("%c", character_ciphervalue);
        }

        // Checks if character is space, punct or number - DONE
        else if ( isupper(text[i]) == false && islower(text[i]) == false )
        {
            printf("%c", text[i]);
        }
    }
    printf("\n");
}